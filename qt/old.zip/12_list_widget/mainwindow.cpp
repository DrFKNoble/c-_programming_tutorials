#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Add items to listWidget programmatically

    // Adding empty strings and changing them later

    ui->listWidget->addItem(QString());
    ui->listWidget->addItem(QString());

    QListWidgetItem *item = ui->listWidget->item(0);
    item->setText("Apples");

    item = ui->listWidget->item(1);
    item->setText("Oranges");

    // Adding a string immediately

    ui->listWidget->addItem(QString("Bananas"));

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionExit_triggered()
{
    QApplication::exit();

    return;
}

void MainWindow::on_listWidget_currentRowChanged(int currentRow)
{
    QMessageBox::information(this, "Current Row is:", QString::number(currentRow));

    return;
}
