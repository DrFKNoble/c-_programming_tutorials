#include <QCoreApplication>
#include <QDebug>
#include <QDir>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QDir appDir = QDir(argv[0]);

    appDir.cd("..");

    qDebug() << "This executable's path is: ";
    qDebug() << appDir.absolutePath() << "\n";

    // Check if path exists

    QDir dir = QDir("C:/Qt");

    qDebug() << "Check whether" << dir.absolutePath() << "exists!";
    if (dir.exists())
    {
        qDebug() << dir.absolutePath() << "exists!" << "\n";
    } else {
        qDebug() << dir.absolutePath() << "doesn't exist!" << "\n";
    }

    // Display all drives

    for(auto f : dir.drives())
    {
        qDebug() << f.absolutePath();
    }
    qDebug() << "\n";

    // Create a path

    QString newPath = appDir.absolutePath() + "/temp";
    QDir newDir = QDir(newPath);

    qDebug() << "The new path is: ";
    qDebug() << newPath << "\n";

    if (!newDir.exists())
    {
        newDir.mkdir(newPath);
    } else {
        qDebug() << newPath << "exists!" << "\n";
    }

    // List files in dir

    for( auto f : appDir.entryInfoList())
    {
        if( f.isFile() )
        {
            qDebug() << "File: " << f.absoluteFilePath();
        }

        if( f.isDir() )
        {
            qDebug() << "Dir: " << f.absolutePath();
        }
    }

    return a.exec();
}
