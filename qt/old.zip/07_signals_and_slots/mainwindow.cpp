#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionExit_triggered()
{
    QApplication::exit();

    return;
}

void MainWindow::on_actionClear_triggered()
{
    ui->textEdit->clear();

    ui->statusbar->showMessage("The Edit menu's Clear button was pressed");

    return;
}

void MainWindow::on_clearButton_clicked()
{
    ui->textEdit->clear();

    ui->statusbar->showMessage("The Clear button was pressed");

    return;
}
