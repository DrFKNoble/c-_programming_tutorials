#include <iostream>

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QTextStream>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QDir directory = QDir();
    QString appDir = directory.absolutePath();

    std::cout << appDir.toStdString() << std::endl;

    // Write to a file

    QString outputFileName = appDir + "/file.txt";
    QFile outputFile(outputFileName);

    if( !outputFile.open(QFile::WriteOnly | QFile::Text) )
    {
        std::cout << "Could not open file!" << std::endl;

        return 1;
    }

    QTextStream outputStream(&outputFile);

    outputStream << "This string is going to be written to the file" << "\n";

    std::cout << "Written to file: " << std::endl;
    std::cout << "This string is going to be written to the file" << std::endl;

    outputFile.flush();
    outputFile.close();

    // Read from a file

    QString inputFileName = appDir + "/file.txt";
    QFile inputFile(inputFileName);

    if( !inputFile.open(QFile::ReadOnly | QFile::Text) )
    {
        std::cout << "Could not open file!" << std::endl;

        return 2;
    }

    QTextStream inputStream(&inputFile);

    QString line = inputStream.readLine();

    std::cout << "Read from file: " << std::endl;
    std::cout << line.toStdString() << std::endl;

    inputFile.close();

    return a.exec();
}
