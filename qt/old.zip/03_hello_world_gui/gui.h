#ifndef GUI_H
#define GUI_H

#include <QMainWindow>
#include <QString>
#include <QTextEdit>
#include <QVBoxLayout>

class gui : public QMainWindow
{
    Q_OBJECT
public:
    explicit gui(QWidget *parent = nullptr);

    void getMessage(QString *output);
    void setMessage(const QString &input);

private:

    QString message;

    QVBoxLayout *verticalLayout;

    QTextEdit *textEdit;

    QWidget *centralWidget;

};

#endif // GUI_H
