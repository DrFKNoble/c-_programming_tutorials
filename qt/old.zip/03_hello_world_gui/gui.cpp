#include "gui.h"

gui::gui(QWidget *parent) : QMainWindow(parent)
{

    message = "";

    verticalLayout = new QVBoxLayout();

    textEdit = new QTextEdit();

    centralWidget = new QWidget();

    verticalLayout->addWidget(textEdit);

    centralWidget->setLayout(verticalLayout);

    setCentralWidget(centralWidget);

}

void gui::getMessage(QString *output)
{
    *output = message;

    return;
}

void gui::setMessage(const QString &input)
{
    message = input;

    textEdit->setText(message);

    return;

}
