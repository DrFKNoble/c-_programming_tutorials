#include <QApplication>

#include "gui.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    gui g;

    g.setMessage("Hello World!");

    g.show();

    return a.exec();
}
