#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    treeWidget = ui->treeWidget;
    treeWidget->setColumnCount(2);

    rootTreeItem = new QTreeWidgetItem();
    rootTreeItem->setText(0, "root_0");
    rootTreeItem->setText(1, "Root");

    childTreeItem = new QTreeWidgetItem();
    childTreeItem->setText(0, "child_0");
    childTreeItem->setText(1, "Child");

    rootTreeItem->addChild(childTreeItem);

    treeWidget->addTopLevelItem(rootTreeItem);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionExit_triggered()
{
    QApplication::exit();

    return;
}

void MainWindow::on_treeWidget_itemClicked(QTreeWidgetItem *item, int column)
{
    QMessageBox::information(this, "Item Clicked: ", item->text(column));

    return;
}
