#include "gui.h"

gui::gui(QWidget *parent) : QMainWindow(parent)
{

    fileMenu = new QMenu("File");
    fileExit = new QAction("Exit");
    fileMenu->addAction(fileExit);

    editMenu = new QMenu("Edit");
    editClear = new QAction("Clear");
    editMenu->addAction(editClear);

    menuBar = new QMenuBar();
    menuBar->addMenu(fileMenu);
    menuBar->addMenu(editMenu);

    label = new QLabel();
    label->setText("Type in the box below:");

    textEdit = new QTextEdit();

    clearButton = new QPushButton();
    clearButton->setText("Clear");

    centralWidget = new QWidget();

    statusBar = new QStatusBar();

    horizontalLayout = new QHBoxLayout();

    verticalLayout = new QVBoxLayout();

    centralLayout = new QVBoxLayout();

    spacer = new QSpacerItem(1, 1, QSizePolicy::Expanding, QSizePolicy::Fixed);

    status = new QStatusBar();

    verticalLayout->addWidget(label);
    verticalLayout->addWidget(textEdit);

    horizontalLayout->addSpacerItem(spacer);
    horizontalLayout->addWidget(clearButton);

    centralLayout->addLayout(verticalLayout);
    centralLayout->addLayout(horizontalLayout);

    centralWidget->setLayout(centralLayout);

    setMenuBar(menuBar);
    setCentralWidget(centralWidget);
    setStatusBar(status);

    connect(fileExit, SIGNAL(triggered()), this, SLOT(exit()));
    connect(clearButton, SIGNAL(clicked()), this, SLOT(clearButtonPressed()));
    connect(editClear, SIGNAL(triggered()), this, SLOT(editClearPressed()));

}

void gui::clearButtonPressed()
{
    status->showMessage("Clear button pressed.");

    textEdit->clear();

    return;
}

void gui::editClearPressed()
{
    status->showMessage("Edit menu's Clear button pressed.");

    textEdit->clear();

    return;
}

void gui::exit()
{
    QApplication::exit();

    return;
}
