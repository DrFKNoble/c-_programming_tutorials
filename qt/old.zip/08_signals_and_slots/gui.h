#ifndef GUI_H
#define GUI_H

#include <QAction>
#include <QApplication>
#include <QHBoxLayout>
#include <QLabel>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QTextEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QSpacerItem>
#include <QStatusBar>

class gui : public QMainWindow
{
    Q_OBJECT
public:
    explicit gui(QWidget *parent = nullptr);

signals:

private:

    QMenu *fileMenu;
    QAction *fileExit;

    QMenu *editMenu;
    QAction *editClear;

    QMenuBar *menuBar;

    QLabel *label;

    QTextEdit *textEdit;

    QPushButton *clearButton;

    QWidget *centralWidget;

    QStatusBar *statusBar;

    QHBoxLayout *horizontalLayout;

    QVBoxLayout *verticalLayout;

    QVBoxLayout *centralLayout;

    QSpacerItem *spacer;

    QStatusBar *status;

private slots:

    void clearButtonPressed();

    void editClearPressed();

    void exit();

};

#endif // GUI_H
