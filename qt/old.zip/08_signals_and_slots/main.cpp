#include <QApplication>

#include "gui.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    gui g;


    g.show();

    return a.exec();
}
